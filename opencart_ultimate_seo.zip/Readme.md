ULTIMATE SEO PACKAGE
=====================

Opencart ULTIMATE SEO PACKAGE Opencart 2.x.


Author
-------
Jason Clark(mithereal@gmail.com)

Music Coded to: Whitechapel

Installation instructions For ULTIMATE SEO PACKAGE
-------------------------------------------------

Before installing:

1.  Make a back-up of your database and OC application 
2.  Make sure vqmod is installed
3.  Install vqmodmanager (optional)

Installation:

1.  Upload the unzipped folders and files in the Upload folder (not the Upload folder itself)
2.  Enter your OC Admin and go to Modules
4.  Find the ultimate seo package module and install it
5.  Edit ultimate seo package by putting a meta description character number (suggested 180-250) and checking the auto change box.
6.  Click Save and you are ready to manage or view products based on the users permissions

 
Additional notes: 

1.  If you are using other languages than English, you should copy the file "admin/language/english/module/ultimate_seo.php " to your other language directories in admin/languages/
